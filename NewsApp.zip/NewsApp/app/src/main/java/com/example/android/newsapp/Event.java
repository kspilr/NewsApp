package com.example.android.newsapp;

/**
 * Created by Dell on 21-11-2018.
 */

public class Event
{
    public final String NEWS_TITLE;
    public final String NEWS_DETAIL;

    public Event(String news_title, String news_detail) {
        NEWS_TITLE = news_title;
        NEWS_DETAIL = news_detail;
    }
}
