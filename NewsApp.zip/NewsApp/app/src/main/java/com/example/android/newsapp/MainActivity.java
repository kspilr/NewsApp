package com.example.android.newsapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {
    /** Tag for the log messages */
    public static final String LOG_TAG = MainActivity.class.getSimpleName();

    private final static String NEWS_REQUEST_URL="http://content.guardianapis.com/search?q=debates&api-key=test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //to start URL request in background
        AsyncRequest task = new AsyncRequest();
        task.execute();
    }
    private void UpdateUI(Event getNews) {

        TextView N_title = (TextView)findViewById(R.id.N_title);
        N_title.setText(getNews.NEWS_TITLE);
        TextView N_details = (TextView)findViewById(R.id.N_Details);
        N_details.setText(getNews.NEWS_DETAIL);
    }


    private class AsyncRequest extends AsyncTask<URL,Void,Event> {


        @Override
        protected Event doInBackground(URL... urls) {
            //create URL obj
            URL url = createUrl(NEWS_REQUEST_URL);

            //perform http request to url to get jsonresponse
            String JSONResponse = "";

            try
            {
                JSONResponse = makeHttpRequest(url);
            }catch (IOException e)
            {
                e.printStackTrace();
            }

            //Extract news from json response
            Event getNews = extractFeaturesFromJsonResponse(JSONResponse);


            return getNews;
        }

        @Override
        protected void onPostExecute(Event getNews)
        {
            if(getNews==null)
            {
                return;
            }
            UpdateUI(getNews);


        }


        private Event extractFeaturesFromJsonResponse(String jsonResponse) {

            if(jsonResponse==null)
            {
                Log.e(LOG_TAG, "empty JSON results");
            }else
            {
                Log.e(LOG_TAG, " JSON results");
            }
            try {
                JSONObject UpperBaseJsonResponse = new JSONObject(jsonResponse);
                JSONObject baseJsonResponse = UpperBaseJsonResponse.getJSONObject("response");//jsonRespone is converted into json obj
                JSONArray resultArray = baseJsonResponse.getJSONArray("results");//results array is stored inresultArray

                if(resultArray.length()>0)//iif there is some content in resularray
                {
                    JSONObject firstResult = resultArray.getJSONObject(0);
                    //JSONObject result = firstResult.getJSONObject("");

                    String NEWS_title =firstResult.getString("sectionName");
                    String NEWS_content = firstResult.getString("webTitle");

                    return new Event(NEWS_title,NEWS_content);


                }

            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem parsing the NEWS JSON results", e);
            }

            return null;
        }

        private String makeHttpRequest(URL url) throws IOException {
        String JSONResponse="";
            HttpURLConnection urlConnection = null;
            InputStream inputStream=null;

            try
            {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000);
                urlConnection.setConnectTimeout(15000);//milisec
                urlConnection.connect();

                if (urlConnection.getResponseCode() == 200) {
                    inputStream = urlConnection.getInputStream();
                    JSONResponse = readFromStream(inputStream);
                } else {
                    Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
                }



            }catch (IOException e)
            {
                e.printStackTrace();
            }finally{
                if(urlConnection!=null)
                {
                    urlConnection.disconnect();
                }
                if (inputStream!=null)
                {
                    inputStream.close();
                }
                return JSONResponse;
            }

        }

        private String readFromStream(InputStream inputStream)  throws IOException {
            StringBuilder output = new StringBuilder();
            if(inputStream!=null)
            {
                InputStreamReader inputStreamReader= new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line =bufferedReader.readLine();
                while(line!=null)
                {
                    output.append(line);
                    line = bufferedReader.readLine();
                }

            }
            return output.toString();
        }

        private URL createUrl(String stringURL)
        {
            URL url = null;
            try
            {
                url = new URL(stringURL);
            } catch (MalformedURLException e) {
                Log.e(LOG_TAG,"Error creating Url");
                return  null;
            }
            return url;
        }

    }
}
